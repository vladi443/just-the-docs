import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.File;
import java.util.Scanner;
import java.util.ArrayList;
import greenfoot.GreenfootImage;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    public void act()
    {
        String key=Greenfoot.getKey();
        if (l_down!=("l".equals(key))){
            l_down=!l_down;
            System.out.println("l");
        }
        if (n_down!=("n".equals(key))){
            n_down=!n_down;
            System.out.println("n");
        }
        if (s_down!=("s".equals(key))&&s_down_once<1){
            s_down=!s_down;
            s_down_once++;
            auto_sort=true;
            System.out.println("s");
        }
        
        if (auto_sort){
            int lowest=sorting_bars.get(0).getHeight();
            int lowest_index=-1;
            int current_index=0;
            Boolean sorted=false;
            
            while(!sorted){
                
                int current_value=sorting_bars.get(current_index).getHeight();
                for (int i=current_index; i<sorting_bars.size(); i++){
                    if (sorting_bars.get(i).getHeight()<=current_value&&sorting_bars.get(i).getHeight()<=lowest){
                        lowest=sorting_bars.get(i).getHeight();
                        lowest_index=i;
                    }
                }
                
                sorting_bars.get(lowest_index).highlight();
                sorting_bars.get(current_index).highlight();

                int current_x_cord=sorting_bars.get(current_index).getX();
                int lowest_x_cord=sorting_bars.get(lowest_index).getX();
                
                sorting_bars.get(lowest_index).move(current_x_cord-600+(800/total_values));
                sorting_bars.get(current_index).move(lowest_x_cord-(800/total_values/2));
                
                
                
                current_index++;
                break;
            }
            auto_sort=false;
        }
    }
    
    private File file;
    private Scanner file_scanner;
    private Boolean l_down=false, n_down=false, s_down=false;
    private int l_down_once=0, n_down_once=0, s_down_once=0;
    private Boolean auto_sort=false;
    private GreenfootImage l_message=new GreenfootImage("Press Run and the l key to load data file with the num digits and digits.", 22, null, null);
    private ArrayList<SortingBar> sorting_bars=new ArrayList<SortingBar>();
    private int total_values;
    
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1);
        String input_string="";
        int x_location=0;
        try{
            File file = new File("proj2input.txt");
            Scanner file_scanner = new Scanner(file);
            while (file_scanner.hasNextLine()){ 
                input_string=file_scanner.nextLine();
            }
        }catch(Exception e){
            System.out.println("ERROR: Cannot load file!");
        }
        int num_values=Integer.parseInt(input_string.substring(0, input_string.indexOf(" ")));
        total_values=num_values;
        String[] array_values=input_string.split(" ");
        int values[]=new int[num_values];
        
        for (int i=1; i<=num_values; i++){
            values[i-1]=Integer.parseInt(array_values[i]);
        }
        if (!l_down){
            getBackground().drawImage(l_message, 40, 40);
        }
        getBackground().drawImage(new GreenfootImage("Press the n key to step through the selection sort.", 22, null, null), 40, 80);
        getBackground().drawImage(new GreenfootImage("Press the s key to auto step through the selection sort.", 22, null, null), 40, 120);
        for (int i=0; i<num_values; i++){
            SortingBar new_bar=new SortingBar(values[i], 800/num_values);
            addObject(new_bar, x_location*800/num_values+800/num_values/2, (600-values[i]/2));
            sorting_bars.add(new_bar);
            x_location++;
        }
        
    }
}
