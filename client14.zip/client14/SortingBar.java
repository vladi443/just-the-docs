import greenfoot.*;    // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * SortingBar gives a Bar to be used in representing a data value to sort
 * 
 * @author Theresa Jeevanjee based on SAB's original, major changes
 * @version 11/2022
 */
public class SortingBar extends Actor
{
    private int height;  // height of bar in pixels , equalt to data value
    private int width;   // width of bar in pixels
    
    /**
     * Constructor to build a bar
     *    @input height both the height of bar in pixels and the data value of bar
     *    @input width  the width of the bar in pixels
     */
    public SortingBar(int height, int width)
    {
        // Remember the dimensions of this bar ...
        this.height = height;
        this.width = width;
        
        // Create the image for this bar
        setImage(buildImage(width,height));
    }
    
    public void set_Height(int input_height){
        height=input_height;
    }
    // Utility method that takes the size of the bar and returns an equivalent image
    private GreenfootImage buildImage(int width, int height)
    {
        // Build the image ...
        GreenfootImage newImage = new GreenfootImage(width, height);
        // Draw "blue" background for the bar
        newImage.setColor(new Color(23, 20, 99));
        // Draw background for the bar.
        //newImage.setColor(new Color(77,77,77));
        newImage.fill();
        
        // Surround bar with lighter blue box. 
        newImage.setColor(Color.BLUE);
        newImage.drawRect(0,0,newImage.getWidth()-1,newImage.getHeight()-1);
        
        return newImage;
    }
    
    /**
     * Highlight turns the bar yellow, with a green border
     */
    public void highlight()
    {
        // get current image
        GreenfootImage img = getImage();
        
        // make background yellow
        img.setColor(Color.YELLOW);
        img.fill();
        
        // draw greenborder
        img.setColor(Color.GREEN);
        img.drawRect(0,0,img.getWidth()-1,img.getHeight()-1);
    }
    
    /**
     * Unhighlight turns the bar blue, with a lighter blue border (like originally).
     */
    public void unhighlight()
    {
        // get current image
        GreenfootImage img = getImage();
        
        // make background brown
        img.setColor(new Color(23, 20, 99));
        img.fill();
        
        // draw blue rectangle
        img.setColor(Color.BLUE);
        img.drawRect(0,0,img.getWidth()-1,img.getHeight()-1);
    }
    
    /**
     * GetHeight is an accessor to return the bar's height (which is the same 
     * as its data value)
     * 
     *    @returns the height (data value) of the bar
     */
    public int getHeight()
    {
        return height;
    }
   
}
